package com.utilization.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogUtil {
	
	private static LogUtil instance = new LogUtil();
	
	private String fileDeleteLogPath;
	private String fileDeleteLogFile;
	
	
	private LogUtil() {
		fileDeleteLogPath = Config.fileDeleteLogPath;
		fileDeleteLogFile = Config.fileDeleteLogFile;
	}
	
	public static LogUtil getInstance() {
        return instance;
    }	

	public void info(String log) {
		
		try {
		
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");	
			Date date = new Date(System.currentTimeMillis());
			
			String logValue = "["+simpleDateFormat.format(date)+"] [INFO] : " +log;
			
			String logFileName = fileDeleteLogFile.replace("yyyy", simpleDateFormat.format(date).substring(0, 4))
												  .replace("MM", simpleDateFormat.format(date).substring(5, 7))
												  .replace("dd", simpleDateFormat.format(date).substring(8, 10));

			//폴더 존재여부 확인
			File folder = new File(fileDeleteLogPath+"/"+simpleDateFormat.format(date).replaceAll("-", "").substring(0, 8));
			if(!folder.exists()) folder.mkdirs();
				   
			File file = new File(folder.getAbsolutePath()+"/"+logFileName);
			
			if(!file.exists()) file.createNewFile();
			
			BufferedWriter bfw = new BufferedWriter(new FileWriter(file,true));
			
			bfw.newLine();
			bfw.write(logValue);
			bfw.write("");
			bfw.flush();
		
		}catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public static void logDelete(String folderPath, int logDeleteDay) {
			
		File[] files = new File(folderPath).listFiles();

		for (File f : files) {
			if (f.isDirectory()) {
				if (f.getName().length() == 8) {
					try {
						int fileDate = Integer.parseInt(f.getName());
						if (fileDate < logDeleteDay) {
							File[] deleteFolderList = f.listFiles();
							for (int i = 0; i < deleteFolderList.length; i++) {
								deleteFolderList[i].delete();
							}

							deleteFolderList = f.listFiles();
							if (deleteFolderList.length == 0 && f.isDirectory()) {
								f.delete();
							}
						}
					} catch (Exception e) {
					}
				} else {
					logDelete(f.getAbsolutePath(), logDeleteDay);
				}
			}
		}
	}
}
