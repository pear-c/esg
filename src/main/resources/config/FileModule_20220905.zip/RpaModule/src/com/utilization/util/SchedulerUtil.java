package com.utilization.util;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.impl.StdSchedulerFactory;

import com.utilization.scheduler.FileDeleteRun;
import com.utilization.scheduler.LogDeleteRun;

public class SchedulerUtil {

	public SchedulerUtil() {
		SchedulerSetting();
	}

	public void SchedulerSetting() {
		SchedulerFactory schedulerFactory = new StdSchedulerFactory();

		try {
			Scheduler scheduler = schedulerFactory.getScheduler();

			if(Config.fileDeleteUse) {

				//파일 삭제 스케줄러 동작
				FileDeleteScheduler(scheduler);

				//로그파일 삭제 스케줄러 동작
				LogDeleteScheduler(scheduler);
			}

		} catch (SchedulerException e) {
			e.printStackTrace();
		}
	}

	//파일 삭제 스케줄러
	public void FileDeleteScheduler(Scheduler scheduler) throws SchedulerException {
		JobDetail job = newJob(FileDeleteRun.class).withIdentity("FileDelete",Scheduler.DEFAULT_GROUP).build();
		Trigger trigger = newTrigger().withIdentity("FileDeleteTrigger",Scheduler.DEFAULT_GROUP).withSchedule(cronSchedule(Config.fileDeleteCron)).build();

		scheduler.scheduleJob(job,trigger);
		scheduler.start();
	}

	//Log 스케줄러
	public void LogDeleteScheduler(Scheduler scheduler) throws SchedulerException {
		JobDetail job = newJob(LogDeleteRun.class).withIdentity("LogDelete",Scheduler.DEFAULT_GROUP).build();
		Trigger trigger = newTrigger().withIdentity("LogDeleteTrigger",Scheduler.DEFAULT_GROUP).withSchedule(cronSchedule(Config.logDeleteCron)).build();

		scheduler.scheduleJob(job,trigger);
		scheduler.start();
	}

}
