package com.utilization.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.management.ManagementFactory;
import java.net.InetSocketAddress;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;

import javax.management.Query;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.TrustManagerFactory;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

import com.sun.management.OperatingSystemMXBean;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpsConfigurator;
import com.sun.net.httpserver.HttpsParameters;
import com.sun.net.httpserver.HttpsServer;
import com.utilization.scheduler.AttentededReServation;

@SuppressWarnings("restriction")
public class HttpResponse {

	private static Logger logger = Logger.getLogger(HttpResponse.class.getName());
	private Set<Trigger> triggerSet = new HashSet<Trigger>();
	public HttpResponse() {

		// https 사용일 경우
		if (Config.http.equals("https")) {
			HttpsServer server = null;
			try {
				server = HttpsServer.create(new InetSocketAddress(Config.listenPort), 0);
			} catch (Exception e) {
				e.printStackTrace();
			}

			SSLContext sslContext = null;
			try {
				sslContext = SSLContext.getInstance("TLS");
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}

			char[] password = Config.ksPathPassword.toCharArray();
			KeyStore ks;
			KeyManagerFactory kmf = null;
			TrustManagerFactory tmf = null;
			try {
				ks = KeyStore.getInstance(KeyStore.getDefaultType());
				FileInputStream fis = new FileInputStream(Config.ksPath);

				ks.load(fis, password);
				// setup the key manager factory

				kmf = KeyManagerFactory.getInstance("SunX509");
				kmf.init(ks, password);

				// setup the trust manager factory
				tmf = TrustManagerFactory.getInstance("SunX509");
				tmf.init(ks);
			} catch (KeyStoreException e) {
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			} catch (CertificateException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (UnrecoverableKeyException e) {
				e.printStackTrace();
			}
			// setup the HTTPS context and parameters
			try {
				sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
			} catch (KeyManagementException e) {
				e.printStackTrace();
			}

			server.setHttpsConfigurator(new HttpsConfigurator(sslContext) {
	            public void configure(HttpsParameters params) {
	                try {
	                    // initialise the SSL context
	                    SSLContext context = getSSLContext();
	                    SSLEngine engine = context.createSSLEngine();
	                    params.setNeedClientAuth(false);
	                    params.setCipherSuites(engine.getEnabledCipherSuites());
	                    params.setProtocols(engine.getEnabledProtocols());

	                    // Set the SSL parameters
	                    SSLParameters sslParameters = context.getSupportedSSLParameters();
	                    engine.setSSLParameters(sslParameters);

	                } catch (Exception ex) {
	                    System.out.println("Failed to create HTTPS port");
	                }
	            }
	        });

			server.createContext("/Info", new InfoHandler());

			server.createContext("/ping", new pingHandler());

			server.createContext("/UiPathStart", new UiPathStartHandler());

			server.createContext("/UiPathReServation", new UiPathReServationHandler());

			server.setExecutor(Executors.newFixedThreadPool(Config.threadCount));

			server.start();
		}else {
			HttpServer server = null;
			try {
				server = HttpServer.create(new InetSocketAddress(Config.listenPort), 0);
			} catch (NumberFormatException e) {
				logger.error("NumberFormatException => error : "+e.getMessage());
			} catch (IOException e) {
				logger.error("IOException => error : "+e.getMessage());
			}

			server.createContext("/Info", new InfoHandler());

			server.createContext("/ping", new pingHandler());

			server.createContext("/UiPathStart", new UiPathStartHandler());

			server.createContext("/UiPathReServation", new UiPathReServationHandler());

			server.setExecutor(Executors.newFixedThreadPool(Config.threadCount));

			server.start();
		}


	}

	/**
	 * 쿼리스트링 Map으로 리턴
	 *
	 * @param query : query 스트링
	 * @return map
	 */
	private Map<String, Object> queryToMap(String query) {
		Map<String, Object> result = new HashMap<String, Object>();
		for (String param : query.split("&")) {
			String pair[] = param.split("=");
			if (pair.length > 1) {
				result.put(pair[0], pair[1]);
			} else {
				result.put(pair[0], "");
			}
		}
		return result;
	}

	// 핑 리턴 핸들러
	public class pingHandler implements HttpHandler {
		@Override
		public void handle(HttpExchange t) throws IOException {
			logger.info("pingHandler");
			Headers h = t.getResponseHeaders();
			h.add("Content-Type", "text/plain;charset=UTF-8");
			h.add("Access-Control-Allow-Origin", "*");

			t.sendResponseHeaders(200, 0);
			OutputStreamWriter osw = new OutputStreamWriter(t.getResponseBody(), "UTF8");
			osw.write("0");
			try {
				try {
					osw.close();
				}catch (Exception e) {}

				try {
					t.close();
				}catch (Exception e) {}

			}catch (Exception e) {

			}
		}
	}

	public class InfoHandler implements HttpHandler {
		@Override
		public void handle(HttpExchange t) throws IOException {
			Headers h = t.getResponseHeaders();
			h.add("Content-Type", "text/plain;charset=UTF-8");
			h.add("Access-Control-Allow-Origin", "");

			t.sendResponseHeaders(200, 0);
			OutputStreamWriter osw = new OutputStreamWriter(t.getResponseBody(), "UTF8");

			OperatingSystemMXBean osbean =  (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();

			// while(true) {

			String cpuUsage = String.format("%.2f", osbean.getSystemCpuLoad() * 100);

			// System.out.println("CPU Usage : " + cpuUsage);

			// System.out.println("사용가능 메모리 : "
			// +((double)osbean.getFreePhysicalMemorySize()/1024/1024/1024));
			// System.out.println("총 메모리 : " +
			// ((double)osbean.getTotalPhysicalMemorySize()/1024/1024/1024));

			double totalMemory = (double) osbean.getTotalPhysicalMemorySize() / 1024 / 1024 / 1024;
			double useMemory = (double) osbean.getFreePhysicalMemorySize() / 1024 / 1024 / 1024;

			String returnTotalMemory = String.format("%.2f", totalMemory);
			String returnUseMemory = String.format("%.2f", totalMemory - useMemory);

			File file = new File("C:/");

			// String drive = file.getAbsolutePath();

			double totalSize = file.getTotalSpace() / Math.pow(1024, 3);

			double useSize = file.getUsableSpace() / Math.pow(1024, 3);

			double freeSize = totalSize - useSize;

			String returnTotalSize = String.format("%.2f", totalSize);

			String returnUseSize = String.format("%.2f", useSize);

			String returnFreeSize = String.format("%.2f", freeSize);

			/*
			 * System.out.println("하드 디스크 이름 : " + drive);
			 *
			 * System.out.println("전체 디스크 용량 : " + totalSize);
			 * System.out.println("디스크 사용 용량 : " + useSize);
			 * System.out.println("디스크 남은 용량 : " + freeSize);
			 */

			String Data = cpuUsage + "," + returnUseMemory + "/" + returnTotalMemory + "," + returnUseSize + "/"
					+ returnFreeSize;

			// }

			// CPU|메모리(사용가능/총메모리)|디스크(남은용량/총용량)
			osw.write(Data);

			try {
				try {
					osw.close();
				} catch (Exception e) {
					// TODO: handle exception
				}
				try {
					t.close();
				} catch (Exception e) {
					// TODO: handle exception
				}
			} catch (Exception e) {
				// TODO: handle exception
			}

		}
	}

	public class UiPathStartHandler implements HttpHandler {
		@Override
		public void handle(HttpExchange t) throws IOException {

			InputStreamReader isr = new InputStreamReader(t.getRequestBody(),"utf-8");
			//BufferedReader br2 = new BufferedReader(isr);
			//String query = br2.readLine();
			//parse

			//HashMap<String, Object> params = (HashMap<String, Object>) queryToMap(t.getRequestURI().getQuery());
			//HashMap<String, Object> params = (HashMap<String, Object>) queryToMap((new BufferedReader(isr)).readLine());
			JSONParser parser = new JSONParser();
			Object obj = null;
			try {
				obj = parser.parse((new BufferedReader(isr)).readLine());
			} catch (ParseException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			JSONObject params = (JSONObject) obj;

			logger.info("UiPathStart handler => params :" + params.toString());

			//Query q = new Query();
			ArrayList<HashMap<String, Object>> result = new ArrayList<HashMap<String, Object>>();
			JSONObject json = new JSONObject();
			Headers h = t.getResponseHeaders();
			h.add("Content-Type", "text/json;charset=UTF-8");
			h.add("Access-Control-Allow-Origin", "*");

			t.sendResponseHeaders(200, 0);
			OutputStreamWriter osw = new OutputStreamWriter(t.getResponseBody(), "UTF8");
			try {

				// UiPath.Executor.exe 프로세스가 실행중인지 확인하는 명령어
				String processCheck = "cmd /c tasklist | findstr \"UiPath.Executor.exe\"";

				// cmd 명령어 전송
				Process p = Runtime.getRuntime().exec(processCheck);

				BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
				String line = null;
				// 로봇이 실행가능한지 확인하기 위한 변수
				boolean robotStart = true;

				while((line = br.readLine()) != null) {
					// 로봇이 실행중일 경우 프로세스가 검색됨
					robotStart = false;
				}

				String cmd = "C:\\Users\\KHK\\AppData\\Local\\Programs\\UiPath\\Studio\\UiRobot.exe execute --process "+params.get("process");
				if(params.get("input") != null) {
					cmd += " --input \""+params.get("input").toString().replaceAll("\"", "\\\\\"")+"\"";
				}
				//String cmd = "C:\\Users\\KHK\\AppData\\Local\\Programs\\UiPath\\Studio\\UiRobot.exe execute --process "+params.get("process")+" --input \"{'TEST1' : '1245g45g434'}\"";

				// 로봇이 실행 가능할 경우
				if(robotStart) {
					p = Runtime.getRuntime().exec(cmd);
					json.put("success", true);

					Thread.sleep(500);

					String jobId = "";
					String jobKey = "";

					Connection conn = MssqlConnection.orConnect();

					String query = Config.query.get("selectAttendJobInfo");
					PreparedStatement pstmt = conn.prepareStatement(query);
					pstmt.setString(1, params.get("robotId").toString());
					ResultSet rs =  pstmt.executeQuery();

					rs.next();
					jobId = rs.getString("id");
					jobKey  = rs.getString("key");

					if(pstmt != null)try {	pstmt.close();} catch (SQLException e) {e.printStackTrace();}

					query = Config.query.get("updateAttendedInput");

					pstmt = conn.prepareStatement(query);
					pstmt.setString(1, params.get("input").toString());
					pstmt.setString(2, jobId);

					int result1 = pstmt.executeUpdate();
					if(result1 > 0) {
						logger.info("Attended Robot Input Update Success");
					}

					if(pstmt != null)try {	pstmt.close();} catch (SQLException e) {e.printStackTrace();}
					if(conn != null)try {	conn.close();} catch (SQLException e) {e.printStackTrace();}

					conn = MssqlConnection.connect();

					query = Config.query.get("updateattendJobKey");

					pstmt = conn.prepareStatement(query);
					pstmt.setString(1, jobKey);
					pstmt.setString(2, jobId);

					result1 = pstmt.executeUpdate();
					if(result1 > 0) {
						logger.info("Attended Robot JobKey Update Success");
					}

					if(pstmt != null)try {	pstmt.close();} catch (SQLException e) {e.printStackTrace();}
					if(conn != null)try {	conn.close();} catch (SQLException e) {e.printStackTrace();}

				}
				// 로봇 실행이 불가능할 경우
				else {
					json.put("success", false);
				}


			}catch (Exception e) {
				logger.error(e.getMessage());
			}

			osw.write(json.toJSONString().replaceAll("\\\\/", "/"));
			try {
				try {
					osw.close();
				} catch (Exception e) {
					// TODO: handle exception
				}
				try {
					t.close();
				} catch (Exception e) {
					// TODO: handle exception
				}
			} catch (Exception e) {
				// TODO: handle exception
			}

		}
	}

	public class UiPathReServationHandler implements HttpHandler {
		@Override
		public void handle(HttpExchange t) throws IOException {
			HashMap<String, Object> params = (HashMap<String, Object>) queryToMap(t.getRequestURI().getQuery());
			//logger.info("UiPathStart handler => params :" + params.toString());

			//Query q = new Query();
			ArrayList<HashMap<String, Object>> result = new ArrayList<HashMap<String, Object>>();
			JSONObject json = new JSONObject();
			Headers h = t.getResponseHeaders();
			h.add("Content-Type", "text/json;charset=UTF-8");
			h.add("Access-Control-Allow-Origin", "*");

			t.sendResponseHeaders(200, 0);
			OutputStreamWriter osw = new OutputStreamWriter(t.getResponseBody(), "UTF8");
			try {
				String cmd = "C:\\Users\\KHK\\AppData\\Local\\Programs\\UiPath\\Studio\\UiRobot.exe execute --process ATTEST --input \"{'TEST1' : '1245g45g434'}\"";

				// Scheduler 사용을 위한 인스턴스화
	            SchedulerFactory schedulerFactory = new StdSchedulerFactory();
	            Scheduler scheduler = schedulerFactory.getScheduler();

	         // JOB Data 객체
	            JobDataMap jobDataMap = new JobDataMap();
	            jobDataMap.put("cmd", cmd);

	            JobDetail jobDetail = JobBuilder.newJob(AttentededReServation.class)
                        .withIdentity("myJob", "group1")
                        .setJobData(jobDataMap)
                        .build();

	         // CronTrigger
	            CronTrigger cronTrigger = (CronTrigger) TriggerBuilder.newTrigger()
	                                    .withIdentity("trggerName", "cron_trigger_group")
	                                    .withSchedule(CronScheduleBuilder.cronSchedule("00 "+params.get("time")+" 11 11 08 ? 2022")) // 매 5초마다 실행
	                //                    .withSchedule(CronScheduleBuilder.cronSchedule("0 0/2 8-17 * * ?")) // 매일 오전 8시에서 오후 5시 사이에 격분마다 실행
	                                    .forJob(jobDetail)
	                                    .build();


	            triggerSet.add(cronTrigger);

	            scheduler.scheduleJob(jobDetail, triggerSet, false);
	            scheduler.start();

			}catch (Exception e) {
				logger.error(e.getMessage());
			}

			osw.write(json.toJSONString().replaceAll("\\\\/", "/"));
			try {
				try {
					osw.close();
				} catch (Exception e) {
					// TODO: handle exception
				}
				try {
					t.close();
				} catch (Exception e) {
					// TODO: handle exception
				}
			} catch (Exception e) {
				// TODO: handle exception
			}

		}
	}
}
