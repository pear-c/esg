package com.utilization.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MssqlConnection {

	public static Connection connect() {
		Connection conn= null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String connectionUrl = "jdbc:sqlserver://"+Config.mssqlIp
												  +":"+Config.mssqlPort
												  +";database="+Config.mssqlDatabase
												  +";user="+Config.mssqlId
												  +";password="+Config.mssqlPwd;
			conn = DriverManager.getConnection(connectionUrl);
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return conn;
	}

	public static Connection orConnect() {
		Connection conn= null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String connectionUrl = "jdbc:sqlserver://"+Config.orIp
												  +":"+Config.orPort
												  +";database="+Config.orDatabase
												  +";user="+Config.orId
												  +";password="+Config.orPwd;
			conn = DriverManager.getConnection(connectionUrl);
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return conn;
	}
}
