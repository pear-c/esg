package com.utilization.util;

import java.io.File;

public class FileDeleteUtil {
		
	public static final LogUtil logUtil = LogUtil.getInstance();
	
	public static void scanDir(String folderPath, int fileDeleteDay, int logLevel) {
	
		
		File[] files = new File(folderPath).listFiles();

		for (File f : files) {
			if (f.isDirectory()) {
				if (f.getName().length() == 14) {
					try {
						int fileDate = Integer.parseInt(f.getName().substring(0, 8));
						if (fileDate < fileDeleteDay) {
							File[] deleteFolderList = f.listFiles();
							for (int i = 0; i < deleteFolderList.length; i++) {
								if(deleteFolderList[i].delete()) {								
									if (logLevel > 1) {
										logUtil.info("File Delete : " + deleteFolderList[i].getAbsolutePath());
									}
								}
							}

							deleteFolderList = f.listFiles();
							if (deleteFolderList.length == 0 && f.isDirectory()) {

								if (f.delete()) {
									if (logLevel > 0) {
										logUtil.info("Folder Delete : " + f.getAbsolutePath());
									}
								}
							}
						}
					} catch (Exception e) {
					}
				} else {
					scanDir(f.getAbsolutePath(), fileDeleteDay, logLevel);
				}
			}
		}
	}
}
