package com.utilization.scheduler;

import java.util.Date;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.utilization.util.Config;
import com.utilization.util.DateUtil;
import com.utilization.util.LogUtil;

public class LogDeleteRun implements Job {
		
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		System.out.println("LogDeleteRun Executed [" + new Date(System.currentTimeMillis())+ "]");
				
		String fileDeleteLogPath = Config.fileDeleteLogPath;
		String deleteDay = DateUtil.getDateNow("yyyyMMdd", Config.fileDeleteDay);
				
		LogUtil.logDelete(fileDeleteLogPath, Integer.parseInt(deleteDay));
			
		
	}	
	
}
