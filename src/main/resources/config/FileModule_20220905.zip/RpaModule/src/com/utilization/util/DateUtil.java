package com.utilization.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
public class DateUtil {

	public static String getDateNow(String format, int fileDeleteDay) {
		
		String result = null;
		
		Date date = new Date();
		
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		
		Calendar cal = Calendar.getInstance();
		
		cal.setTime(date);
		cal.add(Calendar.DATE, -fileDeleteDay);
		
		result = sdf.format(cal.getTime());
		
		return result;
	}
}
