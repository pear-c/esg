package com.utilization.util;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class InitSetting {

	private static Logger logger = Logger.getLogger(InitSetting.class.getName());

	public InitSetting(){
		init();
	}

	public void init(){
		if(Config.attendedUse && Config.mssqlUse) {

			Connection conn = null;
			PreparedStatement pstmt = null;
			try {
			String name = InetAddress.getLocalHost().getHostName();
			String clientIp = InetAddress.getLocalHost().getHostAddress();
			String query = Config.query.get("updateAttended");

				conn = MssqlConnection.connect();
				pstmt = conn.prepareStatement(query);
				pstmt.setString(1, clientIp);
				pstmt.setString(2, name);

				int result = pstmt.executeUpdate();

				if(result > 0) {
					logger.info("Attended Robot Ip Update Success : "  + clientIp);
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}catch (UnknownHostException e) {
				e.printStackTrace();
			}finally {
				if(pstmt != null)try {	pstmt.close();} catch (SQLException e) {e.printStackTrace();}
				if(conn != null)try {	conn.close();} catch (SQLException e) {e.printStackTrace();}
			}
		}
	}
}
