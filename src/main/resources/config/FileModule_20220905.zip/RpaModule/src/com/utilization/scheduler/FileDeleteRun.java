package com.utilization.scheduler;

import java.io.File;
import java.util.Date;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.utilization.util.Config;
import com.utilization.util.DateUtil;
import com.utilization.util.FileDeleteUtil;

public class FileDeleteRun implements Job {
		
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		System.out.println("FileDeleteRun Executed [" + new Date(System.currentTimeMillis())+ "]");
		
		//파일 삭제 시작
		int fileDeletePathCount = Config.fileDeletePathCount;
		
		if(fileDeletePathCount == 0) return;
		
		String[] fileDeletePath = Config.fileDeletePath;
		String deleteDay = DateUtil.getDateNow("yyyyMMdd", Config.fileDeleteDay);
		int LogLevel = Config.fileDeleteLogLevel;
		
		for(int i=0; i< fileDeletePathCount;i++) {
			File filePath = new File(fileDeletePath[i]);
			
			if(!filePath.isDirectory()) continue;
			
			FileDeleteUtil.scanDir(fileDeletePath[i], Integer.parseInt(deleteDay), LogLevel);
			
		}
		
	}	
	
}
