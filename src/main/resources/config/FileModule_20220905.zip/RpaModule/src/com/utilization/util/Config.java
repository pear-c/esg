package com.utilization.util;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.ini4j.Ini;
import org.ini4j.InvalidFileFormatException;

public class Config {

	// ************************************* 모듈 초기 변수 **********************************************************
	public static int listenPort;
	public static int threadCount;
	public static String portalURL;
	public static String http;
	// http = https 경우 사용
	public static String ksPath;
	public static String ksPathPassword;

	// ************************************* MS-SQL 초기 변수 **********************************************************
	public static boolean mssqlUse;
	public static String mssqlIp;
	public static String mssqlPort;
	public static String mssqlDatabase;
	public static String mssqlId;
	public static String mssqlPwd;

	// ************************************* Orchestrator 초기 변수 **********************************************************
	public static boolean orUse;
	public static String orIp;
	public static String orPort;
	public static String orDatabase;
	public static String orId;
	public static String orPwd;

	// ************************************* 삭제 기능 변수 **********************************************************
	public static boolean fileDeleteUse;
	public static String fileDeleteCron;
	public static int fileDeletePathCount;
	public static String[] fileDeletePath;
	public static int fileDeleteDay;
	public static int fileDeleteLogLevel;
	public static String fileDeleteLogPath;
	public static String fileDeleteLogFile;

	public static String logDeleteCron;
	public static int logDeleteDay;

	// ************************************* attended 관리 변수 **********************************************************
	public static boolean attendedUse;
	public static String batFilePath;
	public static String logFilePath;

	// ************************************* query Map 변수 *************************************************************
	public static Map<String,String> query;

	public Config() {
		ConfigLoad();
	}

	public void ConfigLoad() {

		String filePath = "config/config.ini";

		File iniFile = new File(filePath);
		try {
			Ini ini =new Ini(iniFile);

			// ************************************* 모듈 초기 세팅 **********************************************************
			listenPort = getInt(ini,"setting","listenPort");
			threadCount = getInt(ini,"setting","threadCount");
			portalURL = getString(ini,"setting","portalURL");
			http = getString(ini,"setting","http");
			// https 일 경우만 사용
			if("https".equals(http.toLowerCase())) {
				ksPath = getString(ini,"setting","ksPath");
				ksPathPassword = getString(ini,"setting","ksPathPassword");
			}

			// ************************************* MSSQL 초기 세팅 **********************************************************
			mssqlUse = getBoolean(ini, "mssql", "mssqlUse");

			if(mssqlUse) {
				mssqlIp = getString(ini,"mssql","mssqlIp");
				mssqlPort = getString(ini,"mssql","mssqlPort");
				mssqlDatabase = getString(ini,"mssql","mssqlDatabase");
				mssqlId = getString(ini,"mssql","mssqlId");
				mssqlPwd = getString(ini,"mssql","mssqlPwd");
			}

			// ************************************* Orchestrator 초기 세팅 **********************************************************
			orUse = getBoolean(ini, "orchestrator", "orUse");

			if(orUse) {
				orIp = getString(ini,"orchestrator","orIp");
				orPort = getString(ini,"orchestrator","orPort");
				orDatabase = getString(ini,"orchestrator","orDatabase");
				orId = getString(ini,"orchestrator","orId");
				orPwd = getString(ini,"orchestrator","orPwd");
			}

			// ************************************* 삭제 기능 세팅 **********************************************************
			fileDeleteUse =  getBoolean(ini,"fileDelete","fileDeleteUse");

			if(fileDeleteUse) {
				fileDeleteCron = getString(ini,"fileDelete","fileDeleteCron");
				fileDeletePathCount = getInt(ini,"fileDelete","fileDeletePathCount");

				if(fileDeletePathCount > 0) {
					fileDeletePath = new String[fileDeletePathCount];
					for(int i=0;i<fileDeletePathCount;i++) {
						fileDeletePath[i] = getString(ini,"fileDelete","fileDeletePath"+(i+1));
					}
				}

				fileDeleteDay = getInt(ini,"fileDelete","fileDeleteDay");
				fileDeleteLogLevel = getInt(ini,"fileDelete","fileDeleteLogLevel");
				fileDeleteLogPath = getString(ini,"fileDelete","fileDeleteLogPath");
				fileDeleteLogFile = getString(ini,"fileDelete","fileDeleteLogFile");

				logDeleteCron = getString(ini,"log","logDeleteCron");
				logDeleteDay = getInt(ini,"log","logDeleteDay");
			}

			// ************************************* attended 관리 세팅 **********************************************************
			attendedUse = getBoolean(ini,"attended","attendedUse");
			batFilePath = getString(ini,"attended","batFilePath");
			logFilePath = getString(ini,"attended","logFilePath");

			// ************************************* query Map 저장 *************************************************************
			query = getQuery(ini,"query");

		} catch (InvalidFileFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private String getString(Ini ini, String key, String value) {
		String result = "";

		if(ini.get(key,value) != null) {
			result = ini.get(key,value).toString();
		}

		return result;
	}

	private int getInt(Ini ini, String key, String value) {
		int result = 0;

		if(ini.get(key,value) != null) {
			result = Integer.parseInt(ini.get(key,value).toString());
		}

		return result;
	}

	private boolean getBoolean(Ini ini, String key, String value) {
		boolean result = false;

		if(ini.get(key,value) != null) {
			result = "Y".equals(ini.get(key,value).toString()) ? true : false;
		}

		return result;
	}

	private Map<String,String> getQuery(Ini ini, String key){
		Map<String,String> result = null;

		if(ini.get(key) != null) {
			result = ini.get(key);
		}
		return result;

	}
}
