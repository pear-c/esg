package com.utilization.run;

import com.utilization.util.Config;
import com.utilization.util.HttpResponse;
import com.utilization.util.InitSetting;
import com.utilization.util.SchedulerUtil;

public class RpaModuleRun {

	public static void main(String[] args) {

		//ini파일에서 변수 세팅
		new Config();

		//Attended Robot의 Ip 세팅등 초기 세팅
		new InitSetting();

		//스케줄러 세팅
		new SchedulerUtil();

		new HttpResponse();

	}

}
